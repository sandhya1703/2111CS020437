As a developer, you've been granted access to the APls of five distinct e-commerce companies. Your objective is to develop a responsive React Frontend Web Application that showcases the top N products sold by these companies.
• While ordinarily, registration with each e-commerce company is required separately for your startup, the test server simplifies this process by allowing you to register through a single api for all companies simultaneously.
Are seers All esturns produce ate for to regate or gin tompany wages that you shal devel and
subject to change by the respective e-commerce companies. Generate a custom unique product identifier for the data received to uniquely identify a single product.
: Your applation should const of to pages one for displayingall products and another for showcasing a
specific product. Both pages should exhibit comprehensive details including Name, Company, Category, Price, Rating, Discount, and Availability.
• The all products page must support filtration based on category, e-commerce company, rating, price range, and availability. Products should be sorted by price, rating, discount, and paginated to ensure efficient navigation.
• Employ a random assortment of images as product illustrations for both pages.
• Each API call made by your server to the Test Server incurs a cost and will negatively impact the score you are awarded in this test.
• Your users should receive a timely, performance and accurate response. Therefore, any attempt to minimise costs shouldn't be at the expense of your user's experience or by inaccurately displaying stale product data on your pages
• Your frontend application should solely consume the Test server API to obtain product data and not utilise any third-party APls.
• Utilise any CSS library of your preference such as Material Ul, Tailwind CSS, Bootstrap, etc. Not utilising a CSS library or relying solely on native CSS will result in lower scores.
The timeries panies areine rese me sort isay arine discounts at ridict avalay ior
notice and at any frequency or time. Your app must accommodate the changes made by these e-commerce1
